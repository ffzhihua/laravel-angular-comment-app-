<html>
<head>
    <meta charset="UTF-8">
    <title>title</title>
</head>
<body>
@yield('content')
</body>
</html>