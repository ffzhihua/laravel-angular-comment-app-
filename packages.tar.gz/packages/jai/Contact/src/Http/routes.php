<?php



Route::get('contact', 'ContactController@index');
